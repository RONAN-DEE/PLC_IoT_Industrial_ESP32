// Patch the installed OpenPLC Editor for EQSP32 development. Two patches:
//
// 1. TRUST: add the local dev signing key (keys/eqsp32-dev.pub.pem) to the
//    editor's trusted VPP package keys. The editor (Autonomy-Logic v4.x)
//    bakes its trusted Ed25519 keys into dist/main/main.js inside
//    resources/app.asar and refuses to install (and removes at startup) any
//    package not signed by one of them.
//
// 2. SLOT-0 DISPLAY: renumber the module-slot labels in the renderer from
//    1-based to 0-based. The EQSP32 main unit is a fixed module in the first
//    slot, so with 0-based labels the UI shows the main unit as "Slot 0" and
//    the EQX expansion modules as "Slot 1".."Slot 15" — matching the physical
//    module addresses on the EQX bus. Purely cosmetic: internal slot numbers
//    (vpp_config.h, io-mapping store) are untouched.
//
// The script backs up app.asar -> app.asar.bak on first run, extracts the
// asar, applies whichever patches are missing, repacks (native *.node modules
// stay unpacked) and replaces app.asar.
//
// The OpenPLC Editor must be CLOSED while this runs.
//
// Usage: node tools/patch-editor-trust.mjs

import { execFileSync } from 'node:child_process'
import { copyFileSync, cpSync, existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = dirname(dirname(fileURLToPath(import.meta.url)))
const KEY_ID = 'eqsp32-dev'
const pubPem = readFileSync(join(root, 'keys', `${KEY_ID}.pub.pem`), 'utf-8')

const resourcesDir = join(
  process.env.LOCALAPPDATA,
  'Programs',
  'open-plc-editor',
  'resources',
)
const asarPath = join(resourcesDir, 'app.asar')
const backupPath = join(resourcesDir, 'app.asar.bak')

if (!existsSync(asarPath)) {
  console.error(`app.asar not found at ${asarPath}`)
  process.exit(1)
}

// --- 1. Backup ---------------------------------------------------------------
if (!existsSync(backupPath)) {
  copyFileSync(asarPath, backupPath)
  console.log(`Backed up app.asar -> ${backupPath}`)
}

// --- 2. Extract + patch --------------------------------------------------------
const workDir = mkdtempSync(join(tmpdir(), 'openplc-asar-'))
const extractDir = join(workDir, 'app')
const npxCmd = process.platform === 'win32' ? 'npx.cmd' : 'npx'
const asarCli = (args) => execFileSync(npxCmd, ['--yes', '@electron/asar', ...args], { stdio: 'inherit', shell: true })

asarCli(['extract', `"${asarPath}"`, `"${extractDir}"`])

let changed = false

// --- 2a. Trust key (main.js) ---------------------------------------------------
const mainJsPath = join(extractDir, 'dist', 'main', 'main.js')
let mainJs = readFileSync(mainJsPath, 'utf-8')

if (mainJs.includes(`"${KEY_ID}"`)) {
  console.log('Trust: dev key already present.')
} else {
  // The trusted keys are an inline object literal:
  //   {"openplc-2026":"-----BEGIN PUBLIC KEY-----\n...\n-----END PUBLIC KEY-----\n"}
  const trustRe = /\{"openplc-2026":"-----BEGIN PUBLIC KEY-----\\n[^"]*"\}/
  if (!trustRe.test(mainJs)) {
    console.error('Could not locate the trusted-keys object in main.js — editor version may have changed.')
    process.exit(1)
  }
  const pemJs = pubPem.replace(/\r/g, '').replace(/\n/g, '\\n')
  mainJs = mainJs.replace(trustRe, (m) => `${m.slice(0, -1)},"${KEY_ID}":"${pemJs}"}`)
  writeFileSync(mainJsPath, mainJs)
  console.log(`Trust: inserted key "${KEY_ID}" into main.js`)
  changed = true
}

// --- 2b. Slot-0 display (renderer.js) --------------------------------------------
// Cosmetic renumbering of module-slot labels: internal slot N (1-based) is
// displayed as N-1 so the fixed EQSP32 main-unit module reads "Slot 0" and
// EQX modules read "Slot 1".."Slot 15" (their physical bus addresses).
// ORDER MATTERS: the first replacement must run before the second one
// recreates its search string.
const rendererJsPath = join(extractDir, 'dist', 'renderer', 'renderer.js')
let rendererJs = readFileSync(rendererJsPath, 'utf-8')

if (rendererJs.includes('children:["Slot ",e-1]')) {
  console.log('Slot-0 display: already patched.')
} else {
  const slotPatches = [
    // I/O Mapping table per-slot group header (e = internal slot, 1-based)
    ['children:["Slot ",e]', 'children:["Slot ",e-1]'],
    // Module slot list item (e = array index, 0-based)
    ['children:["Slot ",e+1]', 'children:["Slot ",e]'],
    // Slot detail panel heading (b = array index, 0-based)
    ['children:["Slot ",b+1]', 'children:["Slot ",b]'],
    // Module search placeholder "(slot N)"
    ['slotNumber:b+1', 'slotNumber:b'],
    // Variable picker dropdown group label (r.slot = internal, 1-based)
    ['`Slot ${r.slot}: ${r.moduleName}`', '`Slot ${r.slot-1}: ${r.moduleName}`'],
    // Address registry consumer label (e = internal slot, 1-based)
    ['label:`Slot ${e}`', 'label:`Slot ${e-1}`'],
    // Address conflict message (t[1] = internal slot as string)
    ['`VPP slot ${t[1]} channel ${t[2]}`', '`VPP slot ${Number(t[1])-1} channel ${t[2]}`'],
  ]
  let applied = 0
  for (const [from, to] of slotPatches) {
    const idx = rendererJs.indexOf(from)
    if (idx === -1) {
      console.warn(`Slot-0 display: pattern not found (cosmetic, skipped): ${from}`)
      continue
    }
    if (rendererJs.indexOf(from, idx + 1) !== -1) {
      console.warn(`Slot-0 display: pattern not unique, skipped: ${from}`)
      continue
    }
    rendererJs = rendererJs.slice(0, idx) + to + rendererJs.slice(idx + from.length)
    applied++
  }
  if (applied > 0) {
    writeFileSync(rendererJsPath, rendererJs)
    console.log(`Slot-0 display: applied ${applied}/${slotPatches.length} label patches to renderer.js`)
    changed = true
  } else {
    console.warn('Slot-0 display: no patterns matched — editor version may have changed. Slot labels stay 1-based.')
  }
}

// --- 2c. Default aliases (renderer.js) -------------------------------------------
// The module system fills the alias column only from user input. Auto-fill a
// default alias for untouched channels so every channel is usable from the
// variable Location dropdown immediately:
//   - fixed main-unit module: faceplate name with a dot ("ADIO3" -> "ADIO.3")
//   - expansion modules: family code + per-family index + channel label
//     ("eqxio" #1 "X1.DIO3" -> "XIO.1.DIO3")
// User-entered aliases always take precedence (stored aliases win).
// In the minified source: e = slot array index, t = moduleId, n = module
// definition, i = channel, u = slots array, a = stored-alias map, o = key.
const ALIAS_FROM = 'alias:a.get(o)??"",'
const ALIAS_TO =
  'alias:a.get(o)??(n.fixed' +
  '?i.name.replace(/^([A-Za-z]+)(\\d+)$/,"$1.$2")' +
  ':t.replace(/\\d+$/,"").toUpperCase().replace(/^EQ/,"")+"."' +
  '+u.slice(0,e+1).filter((q)=>q&&q.replace(/\\d+$/,"")===t.replace(/\\d+$/,"")).length+"."' +
  '+i.name.replace(/^X\\d+\\./,"")),'

if (rendererJs.includes('alias:a.get(o)??(n.fixed')) {
  console.log('Default aliases: already patched.')
} else {
  const idx = rendererJs.indexOf(ALIAS_FROM)
  if (idx === -1 || rendererJs.indexOf(ALIAS_FROM, idx + 1) !== -1) {
    console.warn('Default aliases: pattern not found or not unique — skipped (aliases stay empty until typed).')
  } else {
    rendererJs = rendererJs.slice(0, idx) + ALIAS_TO + rendererJs.slice(idx + ALIAS_FROM.length)
    writeFileSync(rendererJsPath, rendererJs)
    console.log('Default aliases: auto-fill patch applied to renderer.js')
    changed = true
  }
}

if (!changed) {
  console.log('Nothing to patch.')
  rmSync(workDir, { recursive: true, force: true })
  process.exit(0)
}

// --- 3. Repack + install -------------------------------------------------------
const outAsar = join(workDir, 'out.asar')
asarCli(['pack', `"${extractDir}"`, `"${outAsar}"`, '--unpack', '"*.node"'])

copyFileSync(outAsar, asarPath)
const outUnpacked = `${outAsar}.unpacked`
if (existsSync(outUnpacked)) {
  try {
    cpSync(outUnpacked, `${asarPath}.unpacked`, { recursive: true, force: true })
  } catch (err) {
    // A running editor keeps its loaded .node files locked. The unpacked
    // files never change across our repacks (same serialport prebuilds), so
    // a locked destination is fine as long as the files are already there.
    console.warn(`Warning: could not refresh app.asar.unpacked (${err.code}); existing files kept.`)
  }
}
rmSync(workDir, { recursive: true, force: true })
console.log('Patched app.asar installed. Restart the OpenPLC Editor.')
