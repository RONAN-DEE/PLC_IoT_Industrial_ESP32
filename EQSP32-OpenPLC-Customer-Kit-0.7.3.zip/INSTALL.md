# Install EQSP32CE support in OpenPLC Editor

**Board package version:** 0.7.3  
**Device name in OpenPLC:** EQSP32CE

Use this guide after you download the Erqos OpenPLC kit from the Erqos website (ZIP archive).

---

## What you need


| Requirement       | Details                                                                                                   |
| ----------------- | --------------------------------------------------------------------------------------------------------- |
| OpenPLC Editor    | Version **4.1.4 or newer** (Autonomy Logic / Electron edition)                                            |
| Node.js           | Installed and available on your PATH ([nodejs.org](https://nodejs.org)) — needed once for the trust patch |
| The Erqos kit ZIP | Downloaded from the Erqos site, then extracted to a folder you can find easily                            |


You do **not** need Arduino IDE. OpenPLC downloads the ESP32 tools and EQSP32 libraries on the first compile.

---



## What’s inside the downloaded ZIP

After you extract the archive, you should see something like:

```text
com.erqos.eqsp32-0.7.3.vpp     <- board package to install in OpenPLC
INSTALL.md                     <- this file
USER_MANUAL.html               <- full user guide with illustrations (open in a browser)
USER_MANUAL.md                 <- same guide as Markdown source
docs\manual-images\            <- SVG illustrations used in the user manual
tools\patch-editor-trust.mjs   <- one-time editor trust patch
keys\eqsp32-dev.pub.pem        <- public signing key (safe to keep)
```

If `tools`, `keys`, or the `.vpp` is missing, you downloaded an incomplete kit — get a fresh ZIP from the Erqos site.

---



![Figure - Install flow](docs/manual-images/03-install-flow.svg)

*Install overview. Details for each step are below. For the full illustrated guide, open USER_MANUAL.html in your browser.*

## Step 1 - Install OpenPLC Editor and Node.js

1. Install OpenPLC Editor 4.1.4 or newer if you do not already have it.
2. Install Node.js (LTS is fine). Node is only used once for the trust patch in Step 4 — not for writing PLC programs.
3. Confirm Node works: open a terminal and run:
  ```text
   node -v
  ```
   You should see a version number (for example `v20.x.x`).

---



## Step 2 — Extract the Erqos kit

1. Download the kit ZIP from the Erqos website.
2. Extract it to a simple path, for example:
  ```text
   C:\Users\<YourName>\Downloads\EQSP32-OpenPLC-Kit\
  ```
3. Keep that folder until installation is finished. You will point OpenPLC at the `.vpp` file inside it.

---



## Step 3 — Close OpenPLC Editor

Quit OpenPLC Editor completely before the next step.  
If it is open, the trust patch cannot update the editor safely.

---



## Step 4 — Run the one-time trust patch (required)

OpenPLC only installs board packages signed by keys it trusts. The Erqos kit includes a small script that adds Erqos’ **public** key to your local editor (and enables a few UI helpers: 0-based slot labels and default channel aliases).

1. Open a terminal (PowerShell or Command Prompt).
2. Go to the folder where you extracted the kit. Example:
  ```text
   cd C:\Users\<YourName>\Downloads\EQSP32-OpenPLC-Kit
  ```
   Adjust the path to match where **you** extracted the ZIP.
3. Run:
  ```text
   node tools\patch-editor-trust.mjs
  ```
4. Wait until the script finishes without errors.

What this does:

- Backs up the editor’s `app.asar` to `app.asar.bak`
- Adds Erqos’ public key so `com.erqos.eqsp32-*.vpp` can be installed
- Does **not** send any data to Erqos or the internet

If the script cannot find OpenPLC Editor, install the editor in the default location first, or see **USER_MANUAL.md** for troubleshooting.

---



## Step 5 — Install the board package in OpenPLC

1. Start OpenPLC Editor.
2. Open the **package / board manager** (where third-party boards are added).
3. Choose **Add from file** (wording may vary slightly by editor version).
4. Browse to the extracted kit folder and select:
  ```text
   com.erqos.eqsp32-0.7.3.vpp
  ```
5. Confirm the install succeeds.

---



## Step 6 — Check that EQSP32CE is available

1. Create a new project, or open an existing one.
2. Open **Configuration**.
3. Select device **EQSP32CE**.
4. Open **System Layout**.

You should see **Slot 0 — EQSP32** (the main unit). That means the package is installed correctly.

For pin modes, EQX modules, Modbus, and programming details, open **USER_MANUAL.md** in the same extracted kit.

---



## After an OpenPLC Editor update

If you update or reinstall OpenPLC Editor later, it may replace the patched files and stop trusting the Erqos package.

If that happens:

1. Close OpenPLC Editor.
2. Extract the Erqos kit again if you deleted it (or use your saved copy).
3. Repeat **Step 4** (`node tools\patch-editor-trust.mjs`).
4. If **EQSP32CE** is missing, repeat **Step 5** and install the `.vpp` again.

---



## Security note

The kit includes only a **public** signing key (`keys\eqsp32-dev.pub.pem`).  
Do **not** use a download that also contains a private key file such as `eqsp32-dev.pem`. If you see that file, discard the package and download again from the official Erqos site.

---



## Quick checklist

- [ ] OpenPLC Editor 4.1.4+ installed  
- [ ] Node.js installed (`node -v` works)  
- [ ] Kit ZIP extracted  
- [ ] OpenPLC Editor closed  
- [ ] `node tools\patch-editor-trust.mjs` succeeded  
- [ ] `com.erqos.eqsp32-0.7.3.vpp` added via **Add from file**  
- [ ] Device **EQSP32CE** appears and **System Layout** shows Slot 0  