# EQSP32CE with OpenPLC Editor — User Manual

**Package:** Erqos EQSP32 board support for OpenPLC Editor (`com.erqos.eqsp32`)  
**Version covered:** 0.7.3  
**Target device:** EQSP32CE (ESP32-S3, Wi‑Fi, BLE, built-in Ethernet)  
**Editor:** OpenPLC Editor v4.1.4 or newer (Electron / Autonomy Logic edition)

This guide is for users who want to write IEC 61131-3 programs in OpenPLC Editor and run them on an Erqos EQSP32CE, including EQX expansion modules. It covers installation, system layout, pin modes, expansion modules, Modbus networking, and common pitfalls.

**How to view this manual with illustrations**

- Open `USER_MANUAL.html` in any web browser (recommended - figures render inline).
- Or open this Markdown file in a viewer that supports local SVG images.
- Source drawings are in `docs/manual-images/`.

| Figure | File | Section |
|---|---|---|
| System overview | `docs/manual-images/01-system-overview.svg` | 1 |
| Slot layout | `docs/manual-images/02-slot-layout.svg` | 5 |
| Install flow | `docs/manual-images/03-install-flow.svg` | 3 |
| I/O Mapping concepts | `docs/manual-images/04-io-mapping-concepts.svg` | 5 |
| AOUT vs SAOUT | `docs/manual-images/05-aout-vs-saout.svg` | 8.3 |
| Value scaling | `docs/manual-images/06-value-scaling.svg` | 9 |
| EQXRA protection | `docs/manual-images/07-eqxra-protection.svg` | 8.3 |

---

## 1. What this package provides

![Figure 1 - EQSP32 with OpenPLC system overview](docs/manual-images/01-system-overview.svg)

*Figure 1. OpenPLC Editor and EQConnect work with the EQSP32CE and chained EQX modules.*

Once installed, OpenPLC Editor can:

- Select **EQSP32CE** as the compile/upload target
- Configure the EQSP32 main-unit terminals and up to 15 EQX modules in one place (**System Layout**)
- Compile and upload PLC programs through the official **EQSP32 Arduino library**

Because I/O goes through that library, these continue to work alongside the PLC runtime:

- **BLE provisioning** with the EQConnect mobile app
- Automatic **Wi‑Fi / Ethernet** management (CE)
- Library networking / MQTT services (as configured outside OpenPLC)

There is **no separate Pin Mapping table** for this board. All I/O is configured under **Configuration → System Layout**.

---

## 2. Prerequisites

| Item | Requirement |
|---|---|
| OpenPLC Editor | v4.1.4 or newer (Windows install used for this package) |
| Node.js | Required once, to run the trust-patch script |
| USB | USB cable to the EQSP32CE for first upload (COM port) |
| Internet | First compile downloads ESP32 core 2.0.17 and libraries |

**Important:** the EQSP32 library is built against **ESP32 Arduino core 2.0.17**. The package pins that version so the editor installs/switches to it automatically on compile.

---

## 3. Installing the board package (customer kit)

The OpenPLC Editor only accepts **cryptographically signed** board packages. Until Erqos is an official signed vendor in the editor, the download kit includes a one-time editor patch that adds Erqos’ public signing key.

![Figure 2 - Install flow from the Erqos website kit](docs/manual-images/03-install-flow.svg)

*Figure 2. Download the kit, extract it, run the one-time trust patch, add the .vpp, then select EQSP32CE.*

For step-by-step commands aimed at website downloads, follow **INSTALL.md** in the kit (extract the ZIP, close OpenPLC, run the Node trust patch, then **Add from file** for the `.vpp`).

### 3.1 Contents of the download kit

```
com.erqos.eqsp32-0.7.3.vpp     Signed board-support package
INSTALL.md                     Quick install for website customers
USER_MANUAL.html               Manual with illustrations (open in a browser)
USER_MANUAL.md                 Manual source (Markdown)
docs/manual-images/            SVG illustrations used in this manual
tools/patch-editor-trust.mjs   One-time editor trust + display patch
keys/eqsp32-dev.pub.pem        Public key only (safe to share)
```

Never distribute the private signing key (`eqsp32-dev.pem`).

### 3.2 After an OpenPLC Editor update

If the editor reinstalls or updates itself, the trust patch may be lost. Close the editor, extract the kit again if needed, and re-run the trust patch from **INSTALL.md**. Reinstall the `.vpp` if **EQSP32CE** is missing.

---

## 4. Creating a project and selecting the device

1. Create or open a project in OpenPLC Editor.
2. Open **Configuration** and select device **EQSP32CE**.
3. Open **Configuration → System Layout**.

You should see:

- **Slot 0 — EQSP32** (fixed; cannot be removed)
- Optional expansion slots (**Add module**) for EQX modules

If slot numbers show as 1, 2, 3… instead of 0, 1, 2… the trust/display patch was not applied. Behavior still works; only labels differ.

---

## 5. System Layout — how EQSP32 I/O is organized

![Figure 3 - System Layout slots match the physical EQX chain](docs/manual-images/02-slot-layout.svg)

*Figure 3. Slot 0 is the fixed EQSP32. Slots 1-15 are EQX modules in physical bus order.*

![Figure 4 - I/O Mapping Mode, address, and alias](docs/manual-images/04-io-mapping-concepts.svg)

*Figure 4. Bind PLC variables with aliases. IEC addresses are auto-assigned and may reflow when Modes change.*

### 5.1 Slot 0 — EQSP32 main unit

| Connector | Channels | Capabilities |
|---|---|---|
| **X1** | `ADIO1`–`ADIO8` | Digital and analog modes |
| **X2** | `DIO9`–`DIO16` | Digital, power PWM, relay, pulse counter |

Each row in the **I/O Mapping** table has:

- **Channel** — faceplate / connector name  
- **Type** — IEC class (digital/analog in/out)  
- **Mode** — electrical function (EQSP32 library mode)  
- **IEC Address** — auto-assigned (`%IX`, `%QX`, `%IW`, `%QW`)  
- **Alias** — friendly name for PLC variables  

### 5.2 Slots 1–15 — EQX expansion modules

Add modules **in the same physical order** they are chained on the EQSP32 expansion bus. Slot order is how the HAL recovers each module’s bus index.

Supported modules in 0.7.3:

| Module | Role |
|---|---|
| EQXIO | 10× digital I/O (DIN / SWT / POUT) |
| EQXAI | 8× analog in (AIN / CIN / TIN) |
| EQXRA | 8× relays + 2× 0–10 V analog outs |
| EQXTC | 6× thermocouple |
| EQXPT | 2× PT100 (2/4-wire or 3-wire per channel) |
| EQXPH | 1× pH |

Maximum practical density is also limited by the OpenPLC Arduino runtime point caps (see §12).

### 5.3 Configuration section (per slot)

Below each slot’s I/O Mapping table is a **Configuration** panel. Only parameters relevant to selected modes appear (for example NTC coefficients when a pin is TIN). Module-level settings (PWM frequency, EQXRA watchdogs) appear at the top of that panel.

---

## 6. Main-unit pin modes and PLC values

Mode labels always start with the EQSP32 library code.

| Mode | Where | IEC | PLC value / notes |
|---|---|---|---|
| DIN (Digital Input) | X1/X2 | `%IX` | 0 / 1 — default ADIO1–4 |
| SWT (Switch Input) | X1/X2 | `%IX` | 0 / 1 — debounce in Configuration |
| AIN (Analog Voltage Input) | X1 only | `%IW` | millivolts (0–5000) — default ADIO5–8 |
| CIN (Current Loop 4-20mA) | X1 only | `%IW` | mA × 100 (e.g. 1200 = 12.00 mA) |
| TIN (NTC Temperature) | X1 only | `%IW` | °C × 10, **signed** — use `WORD_TO_INT` |
| RAIN (Relative Analog Input) | X1 only | `%IW` | 0–1000 relative to 5 V VOut |
| PCC (Pulse Counter) | X2 only | `%IW` | pulses since last read; max **4** active |
| POUT (Digital Output) | X1/X2 | `%QX` | off / on — default DIO9–12, 15–16 |
| POUT (Power PWM Output) | X1/X2 | `%QW` | 0–65535 → 0–100% duty — default DIO13–14 |
| RELAY (Relay Derated Output) | X1/X2 | `%QX` | pull-in then hold; hold % and delay in Configuration |

### 6.1 Main-unit Configuration parameters

| Parameter | Applies when | Notes |
|---|---|---|
| PWM Frequency | Any POUT/RELAY on main unit | Shared for the whole POUT group (Hz) |
| Switch Debounce | SWT | Milliseconds |
| NTC Conversion + coeffs | TIN | Beta, Steinhart-Hart, or Normalized S-H |
| Pulse Edge | PCC | Rising or Falling |
| Relay Hold Power | RELAY | /1000 (1000 = 100%) |
| Relay Derate Delay | RELAY | ms at full power before hold |

---

## 7. Aliases and IEC addresses (important)

IEC addresses are **auto-assigned** (lowest free address per class). Changing a Mode can change a channel’s IEC class and **reflow** addresses.

**Always bind PLC variables using aliases**, not hard-coded addresses.

Default aliases (when the editor patch is applied):

| Hardware | Example alias |
|---|---|
| Main unit ADIO1 | `ADIO.1` |
| Main unit DIO9 | `DIO.9` |
| First EQXIO, DIO3 | `XIO.1.DIO3` |
| Second EQXRA, RL5 | `XRA.2.RL5` |
| First EQXTC, CH1 | `XTC.1.CH1` |

You may rename aliases; user edits always win.

---

## 8. EQX expansion modules in detail

Channel names include the connector prefix (`X1.`, `X2.`, `X3.`) to match the module housing.

### 8.1 EQXIO

| Channels | Modes | PLC |
|---|---|---|
| X1.DIO1–5, X2.DIO6–10 | DIN / SWT / POUT | `%IX` or `%QX` |

SWT debounce appears in Configuration when SWT is selected.

### 8.2 EQXAI

| Channels | Modes | PLC |
|---|---|---|
| X1.CH1–4, X2.CH5–8 | AIN / CIN / TIN | `%IW` — mV / mA×100 / °C×10 |

TIN conversion parameters appear in Configuration (same options as the main unit).

### 8.3 EQXRA

**I/O Mapping (physical terminals only):**

| Channels | Mode | PLC |
|---|---|---|
| X1.RL1–2, X3.RL3–8 | RELAY (Relay Output) | `%QX` on/off |
| X2.AO1–2 | AOUT or SAOUT | `%QW` 0–65535 → 0–10000 mV |

RL1–2 have independent COM; RL3–8 are paired COM (3–4, 5–6, 7–8).

**Not exposed as PLC channels in this release:** AOFB1/2, RLSUP, SYSSTAT, AOSTAT (internal feedback/status).

**AOUT vs SAOUT**

![Figure 5 - EQXRA analog outputs AOUT vs SAOUT](docs/manual-images/05-aout-vs-saout.svg)

*Figure 5. AOUT is independent per channel. SAOUT requires both AO1 and AO2 set to SAOUT.*

| Mode | Behavior |
|---|---|
| AOUT | Independent 0–10 V channel |
| SAOUT | Synchronized AO pair — **set both AO1 and AO2 to SAOUT** |

Mixing AOUT on one channel and SAOUT on the other does not synchronize.  
In package 0.7.3, OpenPLC configures `pinMode(..., SAOUT)` and writes millivolt targets each scan. Full library sync-apply latching (`EQXRA_SAOUT_APPLY`) is not yet used by the HAL; for most applications AOUT is the safer choice unless you specifically need pair sync and have verified behavior on hardware.

**EQXRA Configuration (protection)**

![Figure 6 - EQXRA Configuration protection settings](docs/manual-images/07-eqxra-protection.svg)

*Figure 6. EQXRA watchdogs and feedback-deviation settings live in the Configuration panel, not as PLC channels.*

| Setting | Default | Meaning |
|---|---|---|
| System Watchdog | Enabled | If EQSP32 stops polling the module in time, all relays and AOs disable. Keep enabled. |
| Relay Watchdog Timeout | 200 ms | Shared; no relay command within timeout → all relays off. `0` = disabled. |
| AO1 / AO2 Watchdog Timeout | 1000 ms | Per AO; `0` = disabled. |
| AO1 / AO2 Deviation Threshold + Delay | Off (0 mV) | Fault when command vs feedback deviate too long. |

### 8.4 EQXTC

| Channels | Mode | PLC |
|---|---|---|
| X1.CH1–3, X2.CH4–6 | TC | `%IW` °C × 10, signed → use `WORD_TO_INT` |

### 8.5 EQXPT

| Channels | Mode | PLC |
|---|---|---|
| X1.M1, X2.M2 | PT100 (2/4-wire) or PT100 (3-wire) | `%IW` °C × 10, signed → use `WORD_TO_INT` |

Pick wiring per channel with the Mode dropdown.

### 8.6 EQXPH

| Channel | Mode | PLC |
|---|---|---|
| X1.PH1 | PH | `%IW` pH × 100 (704 = 7.04) |

---

## 9. Working with scaled values in the PLC program

![Figure 7 - Value scaling what the PLC number means](docs/manual-images/06-value-scaling.svg)

*Figure 7. Common raw PLC values and their physical meaning.*

| Signal | Raw `%IW` / `%QW` | How to interpret |
|---|---|---|
| Voltage (AIN) | millivolts | e.g. 2500 = 2.500 V |
| Current (CIN) | mA × 100 | e.g. 2000 = 20.00 mA |
| Temperature (TIN/TC/PT) | °C × 10, signed | Convert with `WORD_TO_INT` before using as INT |
| pH | × 100 | e.g. 704 = 7.04 |
| PWM duty (`%QW`) | 0–65535 | Maps to 0–100% |
| EQXRA AO (`%QW`) | 0–65535 | Maps to 0–10000 mV (0–10 V) |

**Signed temperatures:** OpenPLC analog words are unsigned. Negative °C values require `WORD_TO_INT` (or equivalent) in the program.

---

## 10. Modbus and networking

Open **Configuration → Modbus**.

The EQSP32 library owns Wi‑Fi and (on CE) Ethernet. The OpenPLC Modbus TCP server can listen on those interfaces.

Typical use:

- **Ethernet:** choose Ethernet in the Modbus screen; plug the cable. No SSID needed.
- **Wi‑Fi:** choose Wi‑Fi and enter SSID/password. Credentials are forwarded to the EQSP32 connectivity manager so stacks agree.
- Static IP fields, when set, are forwarded to the library.

BLE / EQConnect provisioning remains available regardless of Modbus network choice.

---

## 11. Compile, upload, and first run

1. Finish System Layout and program logic.
2. Select the correct **COM port** for the EQSP32CE.
3. Build / upload from OpenPLC Editor.
4. First compile may take several minutes while core 2.0.17 and libraries (`EQSP32`, `RadioLib`) download.
5. After upload, the PLC scan runs on the device; use EQConnect if you still need BLE setup.

If compile fails after an editor update, re-apply the trust patch (§3.3) and reinstall the `.vpp` if needed.

---

## 12. Limits and practical cabinet notes

OpenPLC Arduino runtime caps (approximate):

- 56 digital inputs / 56 digital outputs  
- 32 analog inputs / 32 analog outputs  

The EQSP32 can address up to **15** EQX modules. Typical DIN-rail cabinets fit fewer modules beside the controller; stay within both physical space and the point caps above.

PCC on the main unit: at most **4** pulse-counter channels active at once.

---

## 13. Upgrading the package / missing channels

If channels disappear from the I/O Mapping table after a package upgrade (for example AO1/AO2 or ADIO1), the project usually still has an **old Mode string** that the new catalog no longer lists. The editor silently drops those rows.

**Fix:**

1. Close the project (or quit the editor).
2. Run:

   ```text
   node tools/migrate-project-config.mjs "<path-to-your-project-folder>"
   ```

3. Reopen the project.

The tool writes `devices/configuration.json.bak` before changing anything.

---

## 14. Troubleshooting

| Symptom | Likely cause | What to do |
|---|---|---|
| Cannot install `.vpp` / signature error | Trust patch not applied | Close editor, run `patch-editor-trust.mjs` |
| EQSP32CE missing after editor update | `app.asar` restored | Re-run trust patch; reinstall `.vpp` if needed |
| Channel missing from I/O Mapping | Stale Mode in project | Run migrate tool (§13) |
| Slot numbers start at 1 | Display patch not applied | Cosmetic only; or re-run trust patch |
| Empty aliases | Display patch not applied | Enter aliases manually |
| Compile / ABI errors | Wrong ESP32 core | Package pins 2.0.17 — let the editor install it |
| Negative temperature looks huge | Treating `%IW` as unsigned | Use `WORD_TO_INT` |
| EQXRA AOs not syncing as expected | SAOUT apply latch not in HAL yet | Prefer AOUT, or verify on hardware (§8.3) |
| Relays/AOs drop unexpectedly | Watchdog timeout | Increase timeout or keep commanding outputs each scan |

---

## 15. What stays with EQConnect / the EQSP32 library

OpenPLC owns the PLC scan and mapped I/O. The EQSP32 library still owns:

- BLE / EQConnect provisioning  
- Wi‑Fi and Ethernet bring-up (CE)  
- Background connectivity features described in Erqos documentation  

Do not expect OpenPLC’s System Layout to replace EQConnect for device provisioning.

---

## 16. Support scope for this package version (0.7.3)

Included:

- EQSP32CE main unit full Mode set via System Layout  
- EQXIO, EQXAI, EQXRA, EQXTC, EQXPT, EQXPH  
- EQXRA watchdog / feedback-deviation configuration  
- Modbus screen integration with EQSP32 networking  

Not included / deferred:

- PLC mapping of EQXRA internal monitors (AOFB, RLSUP, SYSSTAT, AOSTAT)  
- Full SAOUT synchronized apply latch in the HAL  
- Thermocouple type selection (library exposes a single TC mode)  
- Official OpenPLC store signing (this kit uses Erqos development signing + trust patch)

---

*Erqos Technologies — EQSP32 OpenPLC board support*  
*For hardware and library details, see https://erqos.com and the EQSP32 Arduino library documentation.*
